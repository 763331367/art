//通过$方法获取id
function $(id)
{
    return document.getElementById(id);
}

//切换图片事件
function toChange(obj1,obj2)
{
    obj1.style.filter="opacity: 100";   //设置准备切换图片的属性初始值-绝对定位容器底部隐藏
    obj1.style.opacity="1";
    obj1.style.top='500px';
    obj1.style.left='150px';
    obj1.style.width='200px';
    obj2.style.top='50px';
    obj2.style.left='10px';
    obj2.style.width='480px';
    startMove(obj1,{width: 480, height: 300,left: 10, top: 50},6);  //新图片切换上来
    startMove(obj2,{width: 480, height: 300,left: 10, top: 0,opacity: 0},6,function(){  //链式运动 老图片向上运动并隐藏
        startMove(this,{width: 200, height: 150,left: 150, top: 500},3,function(){  //在隐藏之后移动到之前新图片的位置
            this.style.filter="opacity: 100";   //最终取消透明
            this.style.opacity="1";
        });
    });
}

//s1.jpg 地址转换为 1.jpg;
function reStr(str)
{
    var n=str.lastIndexOf('/');  //图片地址最后一个/位置
    var s1=str.substring(0,n+1);  //获取之前的地址
    var s2=str.substring(n+2);   //获取 / 制后的开头未带字母的图片
    var s=s1+s2;   //合并地址

    return s;
}

//绑定事件方法
function myAddEvent(obj,sEv,fn)
{
    if(obj.attachEvent)    //IE浏览器
    {
        obj.attachEvent('on'+sEv,fn);
    }
    else        //其他浏览器
    {
        obj.addEventListener(sEv,fn,false);
    }
}

//运动事件
function startMove(obj,json,x,endFn)
{
    clearInterval(obj.timer);
    obj.timer=setInterval(function()
    {
        doMove(obj,json,x,endFn);
    },30);
}

//样式改变事件 x为速度减弱参数，越大减弱越小
function doMove(obj,json,x,endFn)
{
    var iCur=0;
    var bStop=true;

    for(var attr in json)
    {

        if(attr=='opacity')
        {
            if(iCur=Math.round(getStyle(obj,attr)*100)==0)
            {
                iCur=Math.round(getStyle(obj,attr)*100)
            }
            else
            {
                iCur=Math.round(getStyle(obj,attr)*100)||100;
            }
        }
        else
        {
            iCur=parseInt(getStyle(obj,attr))||0;
        }

        var iSpeed=(json[attr]-iCur)/x;   //动态调整速度
        iSpeed=iSpeed>0 ? Math.ceil(iSpeed) : Math.floor(iSpeed);  //速度取整数

        if(iCur!=json[attr])
        {
            bStop=false; //只要JSON中一项运动没完成，计时器就不会停止
        }

        if(attr=='opacity')
        {
            obj.style.opacity=(iCur+iSpeed)/100;
            obj.style.filter='alpha(opacity='+(iCur+iSpeed)+')';   //IE兼容处理
        }
        else
        {
            obj.style[attr]=iCur+iSpeed+'px';
        }
    }

    if(bStop)   //全部运动完成
    {
        clearInterval(obj.timer);
        if(endFn)   //如果有回调函数则执行回调函数
        {
            endFn.call(obj);
        }
    }

}

//获取非行间样式
function getStyle(obj,attr)
{
    if(obj.currentStyle)
    {
        return obj.currentStyle[attr];
    }
    else
    {
        return getComputedStyle(obj,false)[attr];
    }
}

//盒子拖拽 obj为点击事件出发的dom对象，oparent为移动的DOM元素
function fnDrag(obj,oParent){
    obj.onmousedown=function(ev){
        var oEvent=ev||event;  // 兼容处理
        var theX=oEvent.clientX-oParent.offsetLeft;  //点击后获取与鼠标与父元素X方向位置
        var theY=oEvent.clientY-oParent.offsetTop;   //点击后获取与鼠标与父元素Y方向位置

        document.onmousemove=fnMove;  //事件对象为document，因此能在整个页面上移动
        document.onmouseup=fnUp;	//鼠标松开后取消之前的移动事件

        function fnMove(ev){
            var oEvent=ev||event;
            var l=oEvent.clientX-theX;  //当前鼠标位置减去之前离父元素位置
            var t=oEvent.clientY-theY;
            if(l<0){   //距离到达屏幕左边缘
                l=0;	//直接设置为0
            }else if(l>document.documentElement.clientWidth-oParent.offsetWidth){  //距离到达屏幕右边缘。
                l=document.documentElement.clientWidth-oParent.offsetWidth;   //直接设置为最大距离
            }
            if(t<0){   //距离到达屏幕上边缘
                t=0;
            }else if(t>document.documentElement.clientHeight-oParent.offsetHeight){  //距离到达屏幕下边缘
                t=document.documentElement.clientHeight-oParent.offsetHeight;
            }
            oParent.style.left=l+"px";   //修改父容器的left
            oParent.style.top=t+"px";   //修改父容器的top，达到移动的效果
        };

        function fnUp(){
            this.onmousemove=null;  //取消onmousemove事件
            this.onmouseup=null;  //取消鼠标松开事件，节省资源
        };

        return false;  // 结束事件
    }
}

//提示文字动画事件 iTime为动画持续事件
function fnTip(obj,txt,pos,val,iTime)
{
    obj.style.left='';
    obj.style.right='';
    obj.style[pos]=val;
    obj.innerHTML=txt;
    startMove(obj,{opacity: 100},8,function(){  //文字淡出
        setTimeout(function()
        {
            startMove(obj,{opacity: 0},8);   //文字消失
        },iTime);
    });
}

//清除obj点击事件
function removeC(obj) {
    obj.onclick=function () {
        return false;
    }
}