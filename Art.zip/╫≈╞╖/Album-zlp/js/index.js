(function () {
	var oBox=$('box');  //父元素
	var oBoxC=$('box-content');   //主体部分
	var oView=$('view');    //图片显示区域包括提示
	var newImg=$('news');   //第二张切换图片
	var oThumb=$('thumb');  //底部图片导航部分
	var oTip=$('tip');      //文字提示


	var oH=oBox.getElementsByTagName('h2')[0];           //标题栏
	var oImg=oView.getElementsByTagName('img')[0];         //第一张显示图片
	var oDiv=$('list').getElementsByTagName('div')[0];  //图片导航区域
	var oLoad=oView.getElementsByTagName('div')[0];        //加载图标
	var aImg=oDiv.getElementsByTagName('img');             //图片导航区域图片
	var oSpan=oThumb.getElementsByTagName('span');         //底部切换页面按钮


	var arr=[];  //存储img属性数组
	var zIndex=3;  //初始的图片z-index大小
	var preIndex=0;   //导航图片上一张移动的图片的位置
	var oldIndex=0;  //导航图片上一张点击的图片的位置
	var bChk=false;  //控制照片放大还是缩小
	var bDown=true;  //记录滚轮方向
	var iNum=0;  //导航图片当前图片位置储存
	var iStart=0;  //初始每页显示的导航图片开始
	var iEnd=13;  //初始每页显示的导航图片最大数量+1

	//容器行内样式加载初始属性值 --- 不是必要
	oBox.style.left=oBox.offsetLeft+'px';
	oBox.style.top=oBox.offsetTop+'px';

	//刚开始将每张图片的位置与src存入数组
	for(var i=0; i<aImg.length; i++)
	{
		arr[i]={left: aImg[i].offsetLeft, top: aImg[i].offsetTop, src: aImg[i].src};
	}

	//每张导航图片绑定事件
	for(var i=0; i<aImg.length; i++)
	{
		//导航栏图片点击事件
		aImg[i].onclick=function()
		{
			if(!oTip.clk)  //第一次点击图片切换按钮时显示提示文字。
			{
				fnTip(oTip,'主窗口按住标题可以拖动；点击大图可放大，放大后鼠标在大图上左右滑动可浏览左右被隐藏部分；也可以用鼠标滚轮和键盘左右方向键来切换哦！','left','0',5000);  //出现文字提示
				oTip.clk=true;   //文本框clk属性为true，下次不再弹出
			}
			if(oldIndex==this.index)   //点击同一张导航图片
			{
				return false;   //直接返回取消事件
			}
			iNum=this.index;   //当前图片位置储存不是很必要，因为onmouseover事件也会赋值
			aImg[oldIndex].className='';  //上一张图片的active属性去掉，相当于黄边框消失
			oldIndex=this.index;   //当前图片位置储存为上一张图片的位置
			aImg[oldIndex].className='active';  //当前图添加active属性
			changePic(this);   //切换主题图片
		};

		//鼠标移过时改变导航图片大小
		aImg[i].onmouseover=function()
		{
			iNum=this.index;
			changeThumb(this);   //改变导航图片大小事件
		};

		//防止导航框移出后点击图片未复原
		oThumb.onmouseout=function()
		{
			if(oldIndex!=this.index)  //鼠标如果悬置其他未被点击的图片，则inum变成那张图片 ，而点击图片位置为oldIndex，因此做判断
			{
				iNum=oldIndex;  //复原inum
				changeThumb(aImg[oldIndex]);  //inum变大  ，此时preindex在mouseover事件中变为此前悬停的图片index
			}
		};
	}

	//照片放大浏览
	function toBig(obj)
	{
		obj.onclick=function(ev)
		{
			var oEv=ev||window.event;
			var disX=oEv.clientX-oBox.offsetLeft;  //初始鼠标位置离容器边框距离

			if(bChk==true) //照片缩小
			{
				startMove(this,{width: 480, height: 300,left: 10,top: 50},3);
				bChk=false;  //切换
			}
			else  //照片放大
			{
				startMove(this,{width: 680, height: 400,left: 0,top: 0},3,function(){
					toMove(this,disX)  //第一次点击的时候就进行一次运动判断
				});
				bChk=true;
			}
		};

		obj.onmousemove=function(ev)  //鼠标移动后进行运动判断
		{
			var oEv=ev||window.event;
			var disX=oEv.clientX-oBox.offsetLeft;
			toMove(obj,disX);
		}
	}

	//页面初始加载事件
	function picShow()
	{
		for(var i=0; i<aImg.length; i++)  //所有导航图片设置属性
		{
			aImg[i].index=i;  //给每张图片绑定index
			aImg[i].style.position='absolute';
			aImg[i].style.display='none';
		}
		for(var i=iStart; i<iEnd+1; i++)  //切换页面时设置导航图片的显示属性
		{
			if(aImg[i])  //如果最后一页显示不全，不存在的img[i]就不需要设置
			{
				aImg[i].style.display='block';
				aImg[i].style.left=arr[i-iStart].left+'px';
				aImg[i].style.top=arr[i-iStart].top+'px';
				aImg[i].style.margin='0';
			}
		}
		if(iNum==0)  //如果是第一张，切换页面时设置每页刚开始时第一张图片属性
		{
			aImg[iStart].className='active';
			aImg[iStart].style.marginLeft='-8px';
			aImg[iStart].style.marginTop='-7px';
			aImg[iStart].style.zIndex=zIndex++;
		}
	}

	//图片放大后移动事件
	function toMove(obj,disX)
	{
		if(bChk==true&&obj.offsetWidth==680)  //只有在图片放大的情况下执行移动事件
		{
			if(disX<250) //250为分界线
			{
				clearInterval(obj.timer);  //清除之前的计时器
				startMove(obj,{left: 0},30);  //向左移
			}else{
				clearInterval(obj.timer);
				startMove(obj,{left: -180},30);  //向右移
			}
		}
	}

	//底部导航图片经过放大事件
	function changeThumb(obj)
	{
		startMove(aImg[preIndex],{width: 28, height: 22,marginLeft: 0,marginTop: 0},8);  //上一张图片恢复正常大小
		startMove(obj,{width: 42, height: 32,marginLeft: -8,marginTop: -7},8);   //鼠标悬指的图片放大
		obj.style.zIndex=zIndex++;   //悬指的图片在最上层
		preIndex=iNum;   //储存现在图片的位置 ，下一次再触发事件是就是上一张图片
	}

	//改变主题图片事件
	function changePic(obj)
	{
		bChk=false;
		oLoad.style.display='block';  //载入图标显示  制后在加载图片事件中在进行判断
		aImg[preIndex].className='';   //先将导航图片位置classname未清除，防止切换页面产生差错
		if(preIndex==0)    //作用为
		{
			aImg[preIndex].style.width='42px';
			aImg[preIndex].style.height='32px';
		}

		//防止切换页面后导航图片位置偏差
		startMove(aImg[preIndex],{width: 28, height: 22,marginLeft: 0,marginTop: 0},8);
		startMove(obj,{width: 42, height: 32,marginLeft: -8,marginTop: -7},8);
		obj.style.zIndex=zIndex++;  //悬指的图片在最上层

		picLoad(newImg,obj);  //图片加载
		preIndex=iNum;   //如果页面切换，再次重置preindex，
		toChange(newImg,oImg);   //图片运动
		oldIndex=iNum;   //如果页面切换，再次重置oldindex
		aImg[oldIndex].className='active';  //导航图片属性再次设置为active
		var tmp=oImg;  //交换新老图片容器
		oImg=newImg;   //
		newImg=tmp;	  //
		toBig(oImg);  //给新图片绑定放大事件
		removeC(newImg); //解除老照片绑定放大事件
	}

	//判断新图片是否存在，从而给新图片设置地址
	function picLoad(obj1,obj2)
	{
		var oPic=new Image();  //创建一张image对象 ，用作判断大图片地址是否存在
		obj1.src=obj2.src;    //若加载未成功，则性图片将第二张图片的地址设置为导航点击图片的地址

		oPic.onload=function()  //image对象加载成功后执行,否则显示加载图标 ，若未加载完成就是相当于没找到的情况
		{
			oLoad.style.display='none';
			obj1.src=this.src;  //加载成功设置大图片地址
		}
		oPic.src=reStr(obj2.src);  //设置地址并加载
	}

	//鼠标滚轮切换页面
	function mouseWheel(ev)
	{
		var oEv=ev||event;

		bDown=oEv.wheelDelta?oEv.wheelDelta<0:oEv.detail>0;  //判断前滚还是后滚

		if(bDown)
		{
			toRight();  //向后一张
		}
		else
		{
			toLeft();  //向前一张
		}
		if(oEv.preventDefault){oEv.preventDefault();}
		return false;
	}

	//向前一张
	function toLeft()
	{
		iNum-=1;
		if(iNum<0)  //到达第一张
		{
			iNum=0;
			return false;
		}

		if(iNum==iStart-1)  //到达导航图片第一张
		{
			iEnd=iStart;  //重新判断导航栏显示照片边界值，之前开头为结束
			iStart-=13;  //重新判断导航栏显示照片边界值，新的开头为之前的减去13
			picShow();   //重新加载导航条页面
		}
		changePic(aImg[iNum]);  //切换图片
	}

	//向后一张
	function toRight()
	{
		iNum+=1;
		if(iNum==aImg.length)  //到达最后一张
		{
			iNum=aImg.length-1;
			return false;
		}
		if(iNum==iEnd)  //到达导航图片最后一张
		{
			iStart=iEnd;   //重新判断导航栏显示照片边界值，之前结束为开头
			iEnd+=13;   //重新判断导航栏显示照片边界值，新的开头为之前的加13，相当于下一页
			picShow();  //重新加载导航条页面
		}
		changePic(aImg[iNum]);
	}

	//键盘抬起事件移动图片
	document.onkeyup=function(ev)
	{
		var oEv=ev||window.event;
		switch(oEv.keyCode)  //判断键码
		{
			case 37:  //按下左键
				toLeft();
				break;
			case 38:  //按下上键
				toLeft();
				break;
			case 39:  //按下右键
				toRight();
				break;
			case 40:  //按下下键
				toRight();
				break;
			default :
				break;
		}
	};

	//前一页点击事件
	oSpan[0].onclick=function()
	{
		if(iStart-13>=0)
		{
			iNum-=13;  //原先位置减去刚好一组
			iStart-=13;  //起始和终止位置改变
			iEnd-=13;
			oldIndex-=13;  //不是必要
			changePic(aImg[iNum]);  //切换图片
			picShow();  //重新加载导航条
		}
		else  //到达第一页
		{
			fnTip(oTip,'已经是第一页了！','left','0px',30);
		}
	};

	//后一页点击事件
	oSpan[1].onclick=function()
	{
		if(iStart+13<aImg.length-1)
		{
			iNum+=13;
			iStart+=13;
			oldIndex+=13;
			if(iNum>aImg.length-1&&iNum>parseInt(aImg.length/13)*13)  //到达最后一页是判断是否超出最大导航图片数量
			{
				iNum=aImg.length-1;  //修改图片位置iNum
				oldIndex=iNum;
			}
			iEnd+=13;
			changePic(aImg[iNum]);
			picShow();
		}
		else  //到达最后一页
		{
			fnTip(oTip,'已经是最后一页了！','right','0px',30);
		}
	};

	//两边导航栏按钮移入移出改变class属性，相当于hover
	oSpan[0].onmouseover=oSpan[1].onmouseover=function()
	{
		this.className+=' hover';
	};
	oSpan[0].onmouseout=function()
	{
		this.className='s1';
	};
	oSpan[1].onmouseout=function()
	{
		this.className='s2';
	};

	myAddEvent(oBoxC,'mousewheel',mouseWheel);  //给IE页面绑定滚轮事件
	myAddEvent(oBoxC,'DOMMouseScroll',mouseWheel);  //给火狐谷歌一类浏览器绑定滚轮事件

	picShow();  //页面加载事件
	toBig(oImg);  //刚开是第一张图片绑定放大事件
	oTip.clk=false;  //控制刚开始是否提示操作
	fnDrag(oH,oBox);  // 盒子移动事件
	picLoad(oImg,aImg[0]);  //加载第一张图片
})();

