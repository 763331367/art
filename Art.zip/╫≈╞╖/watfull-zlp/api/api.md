waterfall02--接口说明
    接口地址1: api/waterFall.php
    请求方式: post
    接口参数: currentPage 当前页 pageSize页容量

    返回数据:
        totalPage       总页数
        pageSize        页容量
        currentPage     当前页
        message         提示信息
        items           数据列表


    
    接口地址2:api/waterFall_smile.php
        跟接口地址1 参数  及返回数据 一致,唯一的区别是数据
