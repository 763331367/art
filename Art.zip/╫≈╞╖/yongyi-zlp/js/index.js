(function () {
    var btnGroup = document.getElementById('nav-btn');
    var btn = btnGroup.getElementsByTagName('a');
    var box = document.getElementById('box');
    var img = box.getElementsByTagName('li');
    var now = 0;
    var autoTimer;

    img[0].style.opacity = '1';
    img[0].style.filter="alpha(opacity:1)";
    btn[0].style.backgroundColor = 'red';

    for(var i = 0;i < btn.length;i++){
        btn[i].index = i;
        btn[i].onclick = function () {

            for(var j = 0;j < btn.length;j++){
                btn[j].style.backgroundColor = '';
                startMove(img[j],'opacity',0);
            }
            now = this.index;
            btn[this.index].style.backgroundColor = 'red';
            startMove(img[this.index],'opacity',100);
        }
    }

    function autoMove() {
        clearInterval(autoTimer);
        autoTimer = setInterval(function () {
            if(now>btn.length-1){
                now = 0;
            }
            btn[now].onclick();
            now++;

        },2000);
    }

    autoMove();

    box.onmouseover = btnGroup.onmouseover = function () {
        clearInterval(autoTimer);
    }

    box.onmouseout = btnGroup.onmouseout = function () {
        autoMove();
    }
})();
(function () {
    var btn = document.getElementById('btnA');
    var box = document.getElementById('titleC');

    btn.onclick = function (e) {

        var isB = getStyle(box,'display');

        if(e&&e.stopPropagation())
            e.stopPropagation();
        else
            window.event.cancelBubble = true;
        if(isB == 'block'){
            box.style.display = 'none';
        }else {
            box.style.display = 'block';
        }


    }

    box.onclick = function(e){
        if(e&&e.stopPropagation())
            e.stopPropagation();
        else
            window.event.cancelBubble = true;
    }

    document.body.onclick = function () {
        box.style.display = 'none';
    }
})();