//判断浏览器种类和版本
function toBrowser()
{
    var browser=navigator.appName;
    var b_version=navigator.appVersion;
    if(browser=="Netscape")
    {
        return true;
    }
    var version=b_version.split(";");
    var trim_Version=version[1].replace(/[ ]/g,"");

    if(browser=="Microsoft Internet Explorer" &&( trim_Version=="MSIE7.0" || trim_Version=="MSIE6.0" || trim_Version=="MSIE8.0"))
    {
        return false;
    }
    else
    {
        return true;
    }
}

//开启运动，判断运动类型
function starMove(obj,target,iType,fnEnd)
{
    if(obj.timer)  //开头清除计时器
    {
        clearInterval(obj.timer);
    }
    if(iType==1)
    {
        var sAttr="";
        obj.iSpeed={};  //给obj设置ispeed属性
        for( sAttr in  target)
        {
            obj.iSpeed[sAttr]=0;
        }
    }
    switch(iType)
    {
        case 0:
            obj.timer=setInterval(function(){doMoveBuffer(obj,target,fnEnd);},20);
            break;
        case 1:
            obj.timer=setInterval(function(){domoveFlexible(obj,target,fnEnd);},20);
            break;
    }
}

//普通运动
function doMoveBuffer(obj,target,fnEnd)
{
    var sAttr="";
    var iEnd=1;
    for(sAttr in target)
    {
        if(toBrowser()==false && target["transform"])
        {
            continue;
        }
        var iNow=parseFloat(css(obj,sAttr));
        if(iNow==target[sAttr])
        {
            continue;
        }
        else
        {
            var iSpeed=(target[sAttr]-iNow)/5;
            iSpeed*=0.75;
            if(iSpeed>0)
            {
                iSpeed=Math.ceil(iSpeed);
            }
            else
            {
                iSpeed=Math.floor(iSpeed);
            }
            css(obj,sAttr,iNow+=iSpeed);
            iEnd=0;
        }
    }
    if(iEnd)
    {
        clearInterval(obj.timer);
        if(fnEnd)
        {
            fnEnd.call(obj);
        }
    }
}

//弹性运动方法
function domoveFlexible(obj,target,fnEnd)
{
    var sAttr="";
    var iEnd=1;  //用于判断是否所有运动都已经完成

    for( sAttr in target)
    {
        if(toBrowser()==false && target["transform"])  //浏览器为IE6~8
        {
            continue;
        }
        var iNow=parseFloat(css(obj,sAttr));  //获取当前属性
        obj.iSpeed[sAttr]+=(target[sAttr]-iNow)/5;  //设置速度
        obj.iSpeed[sAttr]*=0.73;
        if(Math.round(iNow)==target[sAttr] && Math.abs(obj.iSpeed[sAttr])<1)  //到达目标并且速度小于1时终止运动，否则继续做运动
        {
            continue;
        }
        else
        {
            iNow=Math.round(iNow+obj.iSpeed[sAttr]);  //与速度相加
            css(obj,sAttr,iNow); //设置css属性
            iEnd=0;  //false，运动未完成
        }
    }
    if(iEnd)  //只有所有运动完成才为1
    {
        clearInterval(obj.timer);
        if(fnEnd)  //回调函数
        {
            fnEnd.call(obj);
        }
    }
}

//设置css样式
function css(obj, attr, value)
{
    if(arguments.length==2)  //两个传参 ，用于获取属性
    {
        if(attr=="transform")
        {
            return obj.transform;
        }
        var i=parseFloat(obj.currentStyle?obj.currentStyle[attr]:document.defaultView.getComputedStyle(obj, false)[attr]);  //document.defaultView返回当前document对象所关联的window对象
        var val=i?i:0;  //如果i为null则为0 否则为 i
        if(attr=="opacity")
        {
            val*=100;
        }
        return val;
    }
    else if(arguments.length==3)  //三个传参  用于设置属性
    {
        switch(attr)
        {
            case 'width':
            case 'height':
            case 'paddingLeft':
            case 'paddingTop':
            case 'paddingRight':
            case 'paddingBottom':
                value=Math.max(value,0);  //value最小为0
            case 'left':
            case 'top':
            case 'marginLeft':
            case 'marginTop':
            case 'marginRight':
            case 'marginBottom':
                obj.style[attr]=value+'px';  //设置objstyle属性
                break;
            case 'opacity':
                if(value<0)
                {
                    value=0;
                }
                obj.style.filter="alpha(opacity:"+value+")";

                obj.style.opacity=value/100;
                break;
            case 'transform':
                obj.transform=value;
                obj.style["transform"]="rotate("+value+"deg)";  //设置obj旋转多少度
                obj.style["MsTransform"]="rotate("+value+"deg)";  //兼容性处理
                obj.style["MozTransform"]="rotate("+value+"deg)";  //兼容性处理
                obj.style["WebkitTransform"]="rotate("+value+"deg)";  //兼容性处理
                obj.style["OTransform"]="rotate("+value+"deg)";   //兼容性处理
                break;
            default:
                obj.style[attr]=value;
        }

    }
}