//地址切换栏
(function ($) {

    var $sBtn = $('.top-navL a');

    //绑定切换事件
    $sBtn.each(function () {
        $(this).on('click',function () {
            $(this).addClass('active');
            $(this).siblings().removeClass('active');
        })
    })

})(jQuery);

//搜索栏
(function ($) {

    var $sBtn = $('.search-btn a');
    var $sInp = $('.search-input>input');
    var arr = ['1111111','22222222','333333','444444444','555555555'];

    //绑定切换事件
    $sBtn.each(function () {
        $(this).on('click',function () {
            $(this).addClass('active');
            $(this).siblings().removeClass('active');
            $sInp.attr('placeholder',arr[$(this).index()]);
        })
    })

})(jQuery);

//update栏信息运动
(function ($) {

    var $sBox = $('.search-tips');
    var $sTipLi = $('.search-tips ul li');
    var $sTipUl = $('.search-tips ul');
    var $sUp = $('.search-tips-up');
    var $sDown = $('.search-tips-down');

    var str = '';  //字符串容器
    var iNow = 0;  //位置初始值
    var autoTimer = null;  //自动播放计时器
    var iHei = $($sTipLi).first().height();  //单个li高度
    var arrDate = [
        {"name":"萱萱","time":"5分钟前","action":"写了一篇文章","article":"那些灿烂华美的瞬间就此绽放"},
        {"name":"萱萱1","time":"5分钟前","action":"写了一篇文章","article":"那些灿烂华美的瞬间就此绽放"},
        {"name":"萱萱2","time":"5分钟前","action":"写了一篇文章","article":"那些灿烂华美的瞬间就此绽放"},
        {"name":"萱萱3","time":"5分钟前","action":"写了一篇文章","article":"那些灿烂华美的瞬间就此绽放"},
        {"name":"萱萱4","time":"5分钟前","action":"写了一篇文章","article":"那些灿烂华美的瞬间就此绽放"}
    ];

    for(var i = 0;i < arrDate.length;i++){
        str +='<li><span class="name">'+arrDate[i].name+'</span><span class="time">'+arrDate[i].time+'</span><span class="action">'+arrDate[i].action+'</span><span class="article">'+arrDate[i].article+'</span></li>'
    }  //加载初始值
    $sTipUl.empty().html(str);

    //运动方法
    function move(index) {

        iNow += index;

        if(iNow > arrDate.length - 1){
            iNow = 0;
        }
        if(iNow < 0){
            iNow = arrDate.length - 1;
        }
        $sTipUl.stop().animate({top:-iNow*iHei},1000,"elasticOut");

    }

    //自动播放
    function autoPlay() {
        clearInterval(autoTimer);
        autoTimer = setInterval(function () {
            move(1);
        },3000);
    }

    autoPlay();

    $sUp.on('click',function () {
       move(-1) ;
    });  //向上点击

    $sDown.on('click',function () {
        move(1) ;
    });  //向下点击

    $sBox.hover(function () {
        clearInterval(autoTimer);
    },function () {
        autoPlay();
    });  //鼠标移入取消计时器

})(jQuery);

//hot红店铺切换
(function ($) {

    var $sBtn = $('.show>a');
    var $sUl = $('.show-content>ul');

    $sBtn.each(function () {
        $(this).on('click',function () {
            $(this).addClass('active');
            $(this).siblings().removeClass('active');
            $sUl.eq($(this).index()).addClass('display');
            $sUl.eq($(this).index()).siblings().removeClass('display');
        });
    });

})(jQuery);

//load 登录记住用户名密码
(function ($) {

    //记住密码checkbox点击事件
    $('#check').click(function () {
        if($(this).prop('checked')){

            var name = $('#name').val();
            var pass = $('#pass').val();

            if(name == ''||pass == ''){
                alert('用户名或密码不能为空');
                return false;  //用户名和密码不能为空
            }else {
                localStorage.setItem(name+':Name',name);  //存储用户名
                localStorage.setItem(name+':pass',pass);  //存储密码
            }

        }
    });

    //用户名框失去焦点判断是否存在密码
    $('#name').blur(function () {
        var name = $('#name').val();
        if(localStorage.getItem(name+':Name')){

            //直接读取密码
            $('#pass').val(localStorage.getItem(name+':pass'));

        }
    });

    //表单提交确认事件
    $('form').submit(function () {

        var name = $('#name').val();
        var pass = $('#pass').val();

        if(name == ''||pass == ''){
            alert('用户名或密码不能为空');
            return false;
        }

    });

})(jQuery);

//抢卷儿
(function ($) {

    var $sBtn = $('.part1-cont-link>a');
    var $sUl = $('.part1-cont-ul>ul');

    $sBtn.each(function () {
        $(this).on('click',function () {
            $(this).addClass('active');
            $(this).siblings().removeClass('active');
            $sUl.eq($(this).index()).addClass('display');
            $sUl.eq($(this).index()).siblings().removeClass('display');
        });
    });

})(jQuery);

//精彩推荐
(function ($) {

    var $sBtnA = $('.right ul li a');
    var $sImg = $('.left>img');
    var $box = $('.recommend-lun');

    var autoTimer = null;
    var iNow = 0;  //现在图片位置

    $sBtnA.each(function (index) {
        this.num = index
        $(this).on('click',function () {
            iNow = this.num;
            move();
        });
    });

    //运动方法
    function move() {
        if(iNow == $sBtnA.size()){
            iNow = 0;
        }
        $sImg.stop().fadeOut();
        $sImg.eq(iNow).stop().fadeIn();
        $sBtnA.removeClass('active');
        $sBtnA.eq(iNow).addClass('active');
    }

    //自动切换方法
    function autoPlay() {
        autoTimer = setInterval(function () {
            iNow++;
            move();
        },3000);
    }

    autoPlay();

    $box.mouseenter(function () {
        clearInterval(autoTimer);
    });
    $box.mouseleave(function () {
        autoPlay();
    });

})(jQuery);

//hot红店铺切换
(function ($) {

    var $sBtn = $('.map>a');
    var $sUl = $('.map-content>div');

    $sBtn.each(function () {
        $(this).on('click',function () {
            $(this).addClass('active');
            $(this).siblings().removeClass('active');
            $sUl.eq($(this).index()).addClass('active');
            $sUl.eq($(this).index()).siblings().removeClass('active');
        });
    });

})(jQuery);

//bbs论坛
(function ($) {

    var $sLi = $('.bbs>ul>li');

    $sLi.mouseenter(function () {
        $sLi.find('.detail').removeClass('active');
        $(this).find('.detail').addClass('active');
        $sLi.find('.select').addClass('active');
        $(this).find('.select').removeClass('active');

    });
})(jQuery);

//advice
(function ($) {

    var $sBtn = $('.advice-cont-link>a');
    var $sUl = $('.advice-cont-ul>ul');

    $sBtn.each(function () {
        $(this).on('click',function () {
            $(this).addClass('active');
            $(this).siblings().removeClass('active');
            $sUl.eq($(this).index()).addClass('display');
            $sUl.eq($(this).index()).siblings().removeClass('display');
        });
    });

})(jQuery);

//日历
(function ($) {

    var $box = $('.boxc');
    var $li = $('.cal-cont li.active');
    var $dis = $('.day');

    //初始数据
    var arr = [{"month":"7","day":"8","apply":"本日主题性感妹子","dre":"迟到的荣誉--维米尔的写实主义风俗画迟到的是否违反顺丰到付为第三方物流","src":"img/luckyimg.png"},
               {"month":"7","day":"24","apply":"本日主题家庭美食","dre":"好好吃的我的天啊真的好好吃哦我吃饱了不行了吃不下了救命啊我的天啊","src":"img/luckyimg2.png"}
               ];

    //绑定事件
    for(var i = 0;i < $li.size();i++){

        $li.get(i).num = i;
        $li.eq(i).css("background-image","url("+arr[i].src+")");  //初始背景绑定

        $li.eq(i).hover(function () {

            var off = $(this).offset();
            var x = off.left + 45;  //获取x坐标
            var y = off.top - 34;  //获取y坐标

            $li.removeClass('clk');
            $(this).addClass('clk');

            //设置详细内容盒子样式
            $box.css({top:y, left:x});
            $box.stop().fadeIn();
            $box.find('img').attr('src',arr[this.num].src);
            $box.find('.s2').text(arr[this.num].apply);
            $box.find('.box-cont-dre').text(arr[this.num].dre);

            //设置顶部内容样式
            $dis.find('img').attr('src',arr[this.num].src);
            $dis.find('.s1').text(arr[this.num].month);
            $dis.find('.s2').text(arr[this.num].day);
            $dis.find('.s3').text(arr[this.num].apply);
            $dis.find('.box-cont-dre').text(arr[this.num].dre);

        },function () {
            $box.stop().fadeOut();
        });
    }

    //详细内容移入移出事件
    $box.hover(function () {
        $(this).stop().fadeIn();
    },function () {
        $(this).stop().fadeOut();
    })

})(jQuery);

