(function () {
    var iTimer=null;
    var iLeft=0;  //新图片X位置
    var iTop=0;   //新图片Y位置
    var iWidth=20;  //生成img最小宽
    var iHeight=20; //生成img最小高

    //取消右键菜单
    document.oncontextmenu=function()
    {
        return false;
    }

    //鼠标移动事件
    document.onmousemove=function(e)
    {
        var ev=e||window.event;
        iLeft=ev.clientX;  //储存鼠标X位置
        iTop=ev.clientY;   //储存鼠标位置
        return false;
    }

    //鼠标点击按下事件
    document.onmousedown=function(e)
    {
        iTimer=setInterval(function(){  //执行图标添加事件
            toAppend();
        },55);
        return false;
    }

    //鼠标抬起后清除计时器
    document.onmouseup=function()
    {
        clearInterval(iTimer);
    }

    //图标添加事件
    function toAppend()
    {
        var oImg=new Image();  //创建新的img对象
        var sSrc="";
        var iAngle=parseInt(Math.random()*1000)%360;  //取整1~360之前的随机数，控制角度
        var iNubLeft=parseInt(Math.random()*100)%2?-parseInt(Math.random()*70):parseInt(Math.random()*70);  //控制生成图像x方向移动距离  是否为0，1决定是否正负，40~-40
        var iNubTop=parseInt(Math.random()*100)%2?-parseInt(Math.random()*70):parseInt(Math.random()*70);  //控制生成图像y方向移动距离
        var INub=parseInt(Math.random()*90);  //随机1~20决定生成图像宽高增长
        var iNubW=INub+iWidth;  //得到随机大小的宽
        var iNubH=INub+iHeight;
        iNubLeft+=iLeft-50;  //随机移动图片运动的后的位置  -20是为了控制所有最大运动距离鼠标位置相等
        iNubTop+=iTop-50;  //随机移动图片运动的后的位置
        sSrc="img/"+parseInt(Math.random()*100)%5+".png";  //得到0~4随机图片地址
        oImg.src=sSrc;  //新img对象src设置
        oImg.onmousemove=function()  //（不必要）取消新图片的鼠标移入事件--防止鼠标移动时移入到新生成的图标中
        {
            return false;
        };
        with(oImg.style)  //with方法逐个设置oImg的属性
        {
            width=iWidth+"px";
            height=iHeight+"px";
            position="absolute";
            left=iLeft-(iNubW/2)+"px";  //设置新图片中心的起始位置在鼠标处
            top=iTop-(iNubH/2)+"px";
        }
        css(oImg,"transform",iAngle);  //设置oimg的rotate属性 ，旋转角度
        document.body.appendChild(oImg);   //将新img对象添加到body上
        starMove(oImg,{left:iNubLeft,top:iNubTop,width:iNubW,height:iNubH},1,function () {
            starMove(oImg,{opacity:0},0,function () {  //图标变淡
                css(oImg,'display','none');  //图标隐藏
            });
        });  //开启运动
    }
})();