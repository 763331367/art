// (function ($) {
//     $.fn.extend({
//         addAnimateCss: function (animationName) {
//             var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
//             $(this).addClass('animated ' + animationName).one(animationEnd, function() {
//                 $(this).removeClass('animated ' + animationName);
//                 $(this).addClass('active');
//             });
//         },
//         removeAnimateCss: function (animationName) {
//             var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
//             $(this).addClass('animated ' + animationName).one(animationEnd, function() {
//                 $(this).removeClass('animated ' + animationName);
//                 $(this).removeClass('active');
//             });
//         },
//     });
// })(jQuery);

//top-left切换按钮样式
(function ($) {
    $btn = $('.top-left>ul>li a');
    $box = $('.top-left .cont');
    $btn.each(function (index) {
        this.num = index;
        $(this).click(function () {
            $btn.parent().removeClass('active');
            $(this).parent().addClass('active');
            $box.stop().fadeOut();
            $box.eq(this.num).stop().fadeIn();
        });
    });
})(jQuery);