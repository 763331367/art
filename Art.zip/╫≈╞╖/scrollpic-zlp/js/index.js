window.onload=function()
{
    var oDiv=document.getElementById('box');  //获取容器
    mouseScroll(oDiv);  //执行初始事件
};

//初始事件
function mouseScroll(obj)
{
    if(!obj) return false;  //没有传参直接结束事件
    var oSpan=document.getElementsByTagName('h1')[0].getElementsByTagName('span')[0];  //提示时间文本框
    var oUl=obj.getElementsByTagName('ul')[0];  //获取ul标签
    var aLi=oUl.getElementsByTagName('li');  //li标签数量，相当于图片数量
    var iLiWidth=[];  //存放每张img宽度
    var iCurr=0;  //默认当前照片位置
    var iPicTarget=0;  //第一张照片到当前照片之和
    var iUlResult=0;  //全部img的width之和
    var iNow=1;  //照片切换的数量和方向
    var iCountTime=null;  //等待时间计时器
    var autoTime=null;  //自动运动计时器

    for(var i=0; i<aLi.length; i++){
        iLiWidth.push(aLi[i].offsetWidth);	//将每个img的宽度储存到数组里
    }
    for(var i=0; i<iLiWidth.length; i++){
        iUlResult+=iLiWidth[i];
    }
    oUl.style.width=iUlResult+2+'px';  //动态设置ul标签的长度
    autoStyle();  //页面刚加载时设置为box的宽度为第一张，以及left

    //窗口大小改变时重置box宽度和left，主要是设置left
    window.onresize=function(){
        autoStyle();
    };

    //动态创建顶部a标签
    var oP=document.createElement('p');
    for(var i=0; i<aLi.length; i++)
    {
        var oA=document.createElement('a');
        oA.href='http://www.miaov.com/';
        oA.target='_blank';
        oA.innerHTML=i+1;
        oP.appendChild(oA);
    }
    oP.getElementsByTagName('a')[0].className='active';  //默认p第一个标签为选中
    obj.appendChild(oP);  //添加p标签

    //每个a标签绑定事件
    for(var i=0,aA=obj.getElementsByTagName('p')[0].getElementsByTagName('a'); i<aA.length; i++)
    {
        aA[i].index=i;  //每个p里的a标签绑定index
        aA[i].onmouseover=function()  //移入切换图片事件
        {
            clearInterval(autoTime);  //清除自动运动计时器
            iCurr=this.index;
            picScroll();  //切换到当前index位置图片
        };
        aA[i].onmouseout=function(){  //鼠标移出任意一个p就在执行完切换事件后开始计时事件
            countTime();  //开始计时事件
        };
    }

    addScrollEvent(document, [mouseDown, mouseUp]);  //绑定滚轮事件

    autoPlay(); //页面加载时执行自动播放事件

    //键盘点击事件
    document.onkeydown=function(ev)
    {
        clearInterval(autoTime);
        countTime();

        ev=ev||window.event;
        if(ev.keyCode==37) //点击左键
        {
            iCurr--;
        }
        if(ev.keyCode==39) //点击右键
        {
            iCurr++;
        }
        picScroll();
    }

    //向下滚动事件
    function mouseDown()
    {
        clearInterval(autoTime);  //清除自动运动计时器
        countTime();  //执行提示切换事件
        iCurr++;  //当前照片为iCurr++
        picScroll();  //图片切换事件
    }

    //向上滚动事件
    function mouseUp()
    {
        clearInterval(autoTime);  //清除自动运动计时器
        countTime();
        iCurr--;
        picScroll();
    }

    //照片切换事件
    function picScroll()
    {
        if(iCurr==aLi.length)  //超出最后一张
        {
            iCurr=aLi.length-1;  //就为最后一张，相当于不动
        }
        if(iCurr<0)  //小于0
        {
            iCurr=0;  //为第一张 相当于不懂
        }

        for(var i=0; i<aLi.length; i++)
        {
            oP.getElementsByTagName('a')[i].className='';
        }
        oP.getElementsByTagName('a')[iCurr].className='active';  //切换a标签属性
        oSpan.innerHTML='当前图片是第'+(iCurr+1)+'张';  //更新标签文字为当前位置
        console.log(iCurr);
        var tmpArr=[];  //存储第一张照片到当前照片的每张照片的宽度
        for(var i=0; i<iCurr; i++)
        {
            tmpArr.push(iLiWidth[i]);  //存储第一张照片到当前照片的每张照片的宽度
        }
        iPicTarget=sumFn(tmpArr);  //计算总宽度之和

        startMove(oUl,{left:-iPicTarget});  //设置ul的运动偏移
        startMove(obj,{width:aLi[iCurr].offsetWidth});  //设置当前box的宽度
    }

    //自动播放事件
    function autoPlay()
    {
        clearInterval(autoTime);  //每次执行前先清除之前的运动
        autoTime=setInterval(function(){
            if(iCurr==aLi.length-1)  //运动到底
            {
                iNow=-1;  //反向运动
            }
            if(iCurr==0)  //运动到第一张
            {
                iNow=1;  //正向运动
            }
            iCurr+=iNow;  //更新位置
            picScroll();  //执行运动事件
        }, 2000);
    }

    //及时事件，停止10秒后开始自动播放
    function countTime()
    {
        var iNum=10;  //每次重置等待时间
        clearInterval(iCountTime);  //清除之前的暂停计时器
        iCountTime=setInterval(function(){
            if(iNum==0)
            {
                oSpan.innerHTML='第0秒后自动播放';
                clearInterval(iCountTime);  //清除自动播放计时器
                autoPlay();  //执行自动播放
            }
            else
            {
                iNum--;  //每次减一
                oSpan.innerHTML='第'+(iNum+1)+'秒后自动播放';  //更新文本框
            }
        }, 1000);  //每一秒执行一次
    }

    //重置当前box的宽度为照片宽度以及left属性
    function autoStyle()
    {
        obj.style.width=aLi[iCurr].offsetWidth+'px';
        obj.style.left=(document.documentElement.clientWidth-obj.offsetWidth)/2+'px';
    }
}

//累加算法
function sumFn(arr)
{
    var result=0;
    for(var i=0; i<arr.length; i++)
    {
        result+=arr[i];
    }
    return result;
}

//绑定滚轮事件
function addScrollEvent()
{
    var obj=arguments[0];  //获取绑定对象
    var functionSet=arguments[1];  //获取方法集
    function scrollEvent(ev)
    {
        var oEvent=ev||event;  //获取事件对象
        var down=false;  //用来判断方向 向下为true 向上为false
        if(oEvent.wheelDelta){  //IE  Chrome
            down=oEvent.wheelDelta<0?true:false;
        }else{  //火狐
            down=oEvent.detail<0?false:true;
        }
        if(down){
            functionSet[0]();	//执行向下滚动事件
        }else{
            functionSet[1]();   //执行向上滚动时间
        }
        if(oEvent.preventDefault){   //如果对象有默认事件，则阻止默认事件
            oEvent.preventDefault();
        }
        return false;  //中止事件
    }
    if(obj.addEventListener){  //火狐浏览器
        obj.addEventListener('DOMMouseScroll', scrollEvent, false);
    }
    obj.onmousewheel=scrollEvent;  //其他浏览器绑定滚轮事件
}