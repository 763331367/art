//top-left切换按钮样式
(function ($) {
    $btn = $('.top-left>ul>li a');
    $box = $('.top-left .cont');
    $btn.each(function (index) {
        this.num = index;
        $(this).click(function () {
            $btn.parent().removeClass('active');
            $(this).parent().addClass('active');
            $box.removeClass('active');
            $box.eq(this.num).addClass('active');
        });
    });
})(jQuery);