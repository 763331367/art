var zSmallBox = document.getElementById("small-box");  //正常图片容器
var zSpa = document.getElementsByTagName("span")[0]; //取标签名为span的数组中第一个元素
var zBigBox = document.getElementById("big-box");  //放大图片容器
var zImg = document.getElementById("big-img");  //放大照片

zSmallBox.onmouseover = function() {  //移入

    zSpa.style.display = "block";  //黑色覆盖框显示
    zBigBox.style.display = "block";  //放大图片容器显示

}
zSmallBox.onmouseout = function() {  //移出

    zSpa.style.display = "none";  //黑色覆盖消失
    zBigBox.style.display = "none";  //放大图片消失

}
zSmallBox.onmousemove = function(e) {

    zSpa.style.left = e.clientX - zSmallBox.offsetLeft - zSpa.offsetWidth / 2 + "px"; //使得黑色覆盖的中心为鼠标位置
    zSpa.style.top = e.clientY + document.documentElement.scrollTop - zSmallBox.offsetTop - zSpa.offsetHeight / 2 + "px";  //得黑色覆盖的中心为鼠标位置
    if (zSpa.offsetLeft < 0) {  //黑色覆盖超出左边框
        zSpa.style.left = 0 + "px";
    }
    if (zSpa.offsetLeft >= zSmallBox.offsetWidth - zSpa.offsetWidth) {  //黑色覆盖超出右边框
        zSpa.style.left = zSmallBox.offsetWidth - zSpa.offsetWidth + "px";
    }
    if (zSpa.offsetTop < 0) {  //黑色覆盖超出顶部边框
        zSpa.style.top = 0 + "px";
    }
    if (zSpa.offsetTop >= zSmallBox.offsetHeight - zSpa.offsetHeight){  //黑色覆盖超出底边框
        zSpa.style.top = zSmallBox.offsetHeight - zSpa.offsetHeight + "px";
    }


    var bigX = zImg.offsetWidth - zBigBox.offsetWidth;  //大img的最大X移动距离
    var bigY = zImg.offsetHeight - zBigBox.offsetHeight;  //大img的最大Y移动距离

    var percentX = zSpa.offsetLeft / (zSmallBox.offsetWidth - zSpa.offsetWidth);  //小img移动的X百分比
    var percentY = zSpa.offsetTop / (zSmallBox.offsetHeight - zSpa.offsetHeight);  //小img移动的Y百分比
    zImg.style.left = -bigX * percentX + "px";  //-号是因为大img反向运动
    zImg.style.top = -bigY * percentY + "px";

}