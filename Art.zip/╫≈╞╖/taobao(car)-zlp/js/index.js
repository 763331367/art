//导航按钮切换
(function ($) {

    var $btn = $('.link-href>ul>li>a');
    var $box = $('.c-box');

    $btn.each(function (index) {
        this.num = index;
        $(this).click(function () {
            $btn.removeClass('active');
            $(this).addClass('active');
            $box.removeClass('active');
            $box.eq(this.num).addClass('active');
        })
    })

})(jQuery);
//按钮样式及内容切换
(function ($) {
    
    var $btn = $('.cont-btn a');
    var $box = $('.cont-study-box');
    
    $btn.each(function () {
        $(this).click(function () {
            $btn.removeClass('active');
            $(this).addClass('active');
            $box.removeClass('active');
            $box.eq($(this).index()).addClass('active');
        })
    })
    
})(jQuery);