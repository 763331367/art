//轮播图
(function () {
    var box = document.getElementById('box');
    var btn = box.getElementsByTagName('a');
    var li = box.getElementsByTagName('li');
    var divL =  document.getElementById('box_left');
    var divR =  document.getElementById('box_right');
    var i = 0;//第一张图片位置
    var timer = null;//点击计时器
    var autoTimer = null;//自动播放计时器
    var isClick= true;//能否点击

    function move(dre) {
        clearInterval(autoTimer);//清除自动播放计时器
        isClick = false;//禁止点击
        if(dre == 'next'){
            i++;
            if(i == li.length){
                i=0;//最后一张图片时切换到第一张图片
            }
            change(i,'next');
        }else if(dre == 'pre'){
            i--;
            if(i < 0){
                i=li.length-1;//第一张图片切换到最后一张图片
            }
            change(i,'pre');
        }
    }

    function change(num,dre) {
        clearInterval(timer);
        var opa = 100; //要消失图片初始透明度
        var opaR = 0;//要显示图片初始透明度
        var before;//消失图片位置
        if(dre == 'next'){
            if(num == 0){
                before = li.length-1;
            }else {
                before = num - 1;
            }
        }else if(dre == 'pre'){
            if(num == li.length-1){
                before = 0;
            }else {
                before = num + 1;
            }
        }
        timer = setInterval(function () {
            if(opa <= 0){
                if(opaR >= 100){
                    isClick = true;//能否点击为true
                    clearInterval(timer);
                }
                li[before].style.display = 'none';//第一站图片消失后设置为none
                li[num].style.display = 'block';//第二张图片一开始设置伟display
                opaR += 2;//速度
                li[num].style.opacity = (opaR/100).toString();
            }
            opa -= 2;
            li[before].style.opacity = (opa/100).toString();
        },10);
    }
    //自动播放方法
    function autoPlay() {
        autoTimer = setInterval(function () {
            move('next');
        },3000);
    }

    li[0].style.display = 'block';//页面一开始设置第一张图片样式
    li[0].style.opacity = '1';

    btn[1].onclick = function () {
        if(isClick){
            move('next');
        }
    }
    btn[0].onclick = function () {
        if(isClick){
            move('pre');
        }
    }

    autoPlay();

    box.onmouseover = function () {
        clearInterval(autoTimer);
    }
    box.onmouseout = function () {
        autoPlay();
    }
    divL.onmouseover = btn[0].onmouseover = function () {
        clearInterval(autoTimer);
        btn[0].style.display = 'inline-block';
    }
    divL.onmouseout = btn[0].onmouseout= function () {
        btn[0].style.display = 'none';
    }
    divR.onmouseover = btn[1].onmouseover = function () {
        clearInterval(autoTimer);
        btn[1].style.display = 'inline-block';
    }
    divR.onmouseout = btn[1].onmouseout= function () {
        btn[1].style.display = 'none';
    }
})();
//产品列表
(function () {
    var par = document.getElementById('show');
    var box = document.getElementById('show_pt');
    var btn = document.getElementById('show_top').getElementsByTagName('a');
    var ul = box.getElementsByTagName('ul')[0];
    var li = ul.getElementsByTagName('li');

    var width = li[0].clientWidth+20;//容器宽度
    //设置初始定时器
    var timer = null;
    //设置自动运动计时器
    var autotimer = null;
    var now = 0;

    ul.innerHTML = ul.innerHTML + ul.innerHTML;
    ul.style.width = li.length*width + 'px'


    btn[0].onclick = function () {

        //当运动到一半时立刻切换图片位置
        if(now == 0){
            now = li.length/2;
            ul.style.left = -ul.offsetWidth/2 + 'px';  //切换到后半部分
        }
        startMove(ul,-(now-1)*width);  //-1表示前一张的位置
        now--;
    }

    btn[1].onclick = function () {

        //当运动到一半时立刻切换图片位置
        if(now == li.length/2){
            now = 0;
            ul.style.left = '0';  //切换到前半部分
        }
        startMove(ul,-(now+1)*width);  //+1表示下一张的位置
        now++;
    }

    function startMove(obj,target){

        //清除计时器防止重复点击
        clearInterval(timer);

        timer = setInterval(function () {
            var speed =(obj.offsetLeft - target)/8;

            //速度取整
            speed = speed>=0?Math.ceil(speed):Math.floor(speed);

            if(obj.offsetLeft == target){
                clearInterval(timer);  //当到达边界时停止运动清除计时器
                autoMove();  //自动点击事件
            }else{
                obj.style.left = obj.offsetLeft - speed + 'px';  //offsetleft增加
            }
        },30);

    }

    function autoMove(){

        autotimer = setInterval(btn[1].onclick,2000);

    }

    //鼠标移入框内停止自动移动
    par.onmouseover = function(){

        console.log('2');
        clearInterval(autotimer);
        clearInterval(timer);

    }

    //鼠标移出框后开始自动移动
    par.onmouseout = function(){

        autoMove();

    }

    //页面开始执行自动移动
    autoMove();

    // //鼠标移入按钮停止播放
    // btn[0].onmouseover = btn[1].onmouseover = function () {
    //
    //     clearInterval(autotimer);
    //
    // }
    //
    // btn[0].onmouseout = btn[1].onmouseout = function () {
    //
    //     autoMove();
    //
    // }


})();
//注册框
(function () {
    var box = document.getElementById('sign-box');
    var btn = document.getElementById('resign');
    var btnB = document.getElementById('btnBack');
    var bg = document.getElementById('sign_bg');

    btn.onclick = function () {
        box.style.display = 'block';
    }
    box.onclick = function () {
        box.style.display = 'none';
    }
    bg.onclick = function (e) {
        e.stopPropagation();
    }
    btnB.onclick = function () {
        box.style.display = 'none';
    }
})();

