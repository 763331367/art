$(function () {
    let $tabs = $("#tabs li");
    let $list = $("#lists ul");
    let $nav = $("#nav");
    $tabs.each(function (index,value) {
        $(this).on("click",function () {
            $(this).addClass("active");
            $(this).siblings().removeClass("active");
            $list.eq(index).addClass("active");
            $list.eq(index).siblings().removeClass("active");
        });
    });
    $(window).scroll(function () {
        let top = $(document).scrollTop();
        if(top >= 265){
            $nav.addClass("sfixed");
        }
        else {
            $nav.removeClass("sfixed");
        }
    });
});